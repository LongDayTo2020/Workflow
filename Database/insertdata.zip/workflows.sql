INSERT INTO public.workflows (id, name, create_time, create_user, update_time, update_user) VALUES (1, '新增書籍', '2023-06-26 16:47:23.769704', '', null, null);
