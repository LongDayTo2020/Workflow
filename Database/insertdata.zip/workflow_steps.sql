INSERT INTO public.workflow_steps (id, workflow_id, step, final, name, create_time, create_user, update_time, update_user) VALUES (1, 1, 1, 0, '確認書籍資訊', '2023-06-26 16:48:05.212867', '', null, null);
INSERT INTO public.workflow_steps (id, workflow_id, step, final, name, create_time, create_user, update_time, update_user) VALUES (2, 1, 2, 0, '確認書籍去處', '2023-06-26 16:48:17.651374', '', null, null);
INSERT INTO public.workflow_steps (id, workflow_id, step, final, name, create_time, create_user, update_time, update_user) VALUES (3, 1, 3, 0, '確認運送', '2023-06-26 16:48:28.400312', '', null, null);
INSERT INTO public.workflow_steps (id, workflow_id, step, final, name, create_time, create_user, update_time, update_user) VALUES (4, 1, 4, 0, '確認完整性', '2023-06-26 16:48:36.390713', '', null, null);
INSERT INTO public.workflow_steps (id, workflow_id, step, final, name, create_time, create_user, update_time, update_user) VALUES (5, 1, 5, 1, '確認上架', '2023-06-26 16:48:45.668760', '', null, null);
